from rest_framework.test import APITestCase
from rest_framework import status
from bookings.models import Movie, Seat

class MovieApiTests(APITestCase):

    def setUp(self):
        #make the movie and seat
        self.movie = Movie.objects.create(title="Sonic 5", description="We are doing all of sonic in one feature length film")
        self.seat = Seat.objects.create(seatNumber="B2", movie=self.movie)


    def testMovieList(self):
        #test to check if the movie list API returns the correct status code and movie data.
        url = '/movies/'
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn(self.movie.title, str(response.data))

    def testBookSeat(self):
        #test to see if the seat booking API correctly books a seat and returns the status code 200.
        url = f'/movies/{self.movie.id}/seats/{self.seat.id}/book/'
        response = self.client.post(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.seat.refresh_from_db()
        self.assertTrue(self.seat.isBooked)
